package com.loanlease.constants;

/**
 * @author 10667140
 */
public class LoanLeasePortletKeys {

	public static final String LOANLEASE =
		"com_loanlease_LoanLeasePortlet";

}